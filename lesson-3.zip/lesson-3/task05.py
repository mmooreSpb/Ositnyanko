def my_sum():
    sum_res = 0
    ex = False
    while ex == False:
        num_list = input('Введите числа через пробел или Q для выхода: ').split()

        res = 0
        for i in range(len(num_list)):
            if num_list[i] == 'q' or num_list[i] == 'Q':
                ex = True
                break
            else:
                res = res + int(num_list[i])
        sum_res = sum_res + res
        print(f'Сумма чисел составила: {sum_res}')
    print(f'Конечный результат суммы: {sum_res}')


my_sum()
