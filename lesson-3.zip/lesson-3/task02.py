"""
Функция забирающая данные у пользователя
и выводящяя их в строку
"""

def user_list(name, surname, year, city, email, phone):
    return print(f"Имя: {name}, Фамилия: {surname}, Год рождения: {year}, Город проживания: {city}"
                 f"email: {email}, Номер телефона: {phone} ")

user_list(
    name = input("Введите имя пользователя: "),
    surname = input("Введите фамилию пользователя: "),
    year = int(input("Ввидите год рождения: ")),
    city = input("Введите город проживания: "),
    email = input("Введите email: "),
    phone = int(input("Введите телефон пользователя: "))
    )
