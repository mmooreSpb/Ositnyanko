# Второй вариант


def my_funk():
    x = float(input("Введите положительное число: "))
    y = float(input("Введите степень в виде отрицательное числа: "))
    result = x ** y
    return result


print(f'Результат - {my_funk()}')
