"""
Функция для деления двух чисел
arg1: первое число запрашиваемое у пользователя
arg2: второе число запрашиваемое у пользователя
"""

def div_funk(*args):
    try:
        arg1 = int(input("Введите первое число: "))
        arg2 = int(input("Введите второе число: "))
        result = arg1 / arg2
    except ValueError:
        return 'Value error'
    except ZeroDivisionError:
        return "Не стоит делить на ноль:) Все ровно не выйдет"

    return result


print(f"result {div_funk()}")
